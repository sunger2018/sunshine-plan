package hks;

import hks.utils.OkHttpOps;
import org.apache.flink.streaming.api.functions.sink.SinkFunction;

import java.util.Map;

public class HttpSink<T> implements SinkFunction<T> {

    public void invoke(T value, Context context) throws Exception {
        if (value == null) {
            return;
        }
        OkHttpOps.doPost("http://localhost:8989/log/print",
                Map.of("content", value));
    }
}
