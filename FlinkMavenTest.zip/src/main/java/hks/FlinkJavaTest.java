package hks;

import hks.model.Order;
import org.apache.flink.cep.pattern.Pattern;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;

public class FlinkJavaTest {
    public static void main(String[] args) {
        var env = StreamExecutionEnvironment.createLocalEnvironment();
        var input = env.fromElements(Order.of(1, "a", "1", 1, 1L, ""));
        Pattern.<Order>begin("").oneOrMore().optional().followedBy("").subtype(Order.class);
    }
}
