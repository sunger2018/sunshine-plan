package hks;

import java.sql.Timestamp;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

public class NewTimeApiTest {

    public static void main(String[] args) {

        testDuration();
    }

    public static void testDuration() {
        var before = LocalDateTime.of(2023, 12, 19, 20, 30, 10);
        var now = LocalDateTime.now();
        long years = ChronoUnit.YEARS.between(before.toLocalDate(), now.toLocalDate());
        long months = ChronoUnit.MONTHS.between(before.toLocalDate(), now.toLocalDate());
        long days = ChronoUnit.DAYS.between(before.toLocalDate(), now.toLocalDate());
        Duration d = Duration.between(before, now);
        long seconds = d.toSeconds();
        long hours = d.toHours();
        long minutes = d.toMinutes();
        System.out.printf("years=%d, months=%d, days=%d, hours=%d, minutes =%d, seconds=%d",
                years, months, days, hours, minutes, seconds);
    }
}
