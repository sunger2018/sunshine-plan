package hks.model;

import java.util.Objects;

public class Order {

    public Integer id;

    public String produceId;

    public String userId;

    public Integer amount;

    public Long ts;

    public String dt;

    public Order() {

    }

    public Order(Integer id, String produceId, String userId, Integer amount, Long ts, String dt) {
        this.id = id;
        this.produceId = produceId;
        this.userId = userId;
        this.amount = amount;
        this.ts = ts;
        this.dt = dt;
    }

    public static Order of(Integer id, String produceId, String userId, Integer amount, Long ts, String dt) {
        return new Order(id, produceId, userId, amount, ts, dt);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Order order = (Order) o;
        return produceId.equals(order.produceId) && userId.equals(order.userId) && ts.equals(order.ts);
    }

    @Override
    public int hashCode() {
        return Objects.hash(produceId, userId, ts);
    }

    @Override
    public String toString() {
        return "Order{" +
                "id=" + id +
                ", produceId='" + produceId + '\'' +
                ", userId='" + userId + '\'' +
                ", amount=" + amount +
                ", ts=" + ts +
                ", dt='" + dt + '\'' +
                '}';
    }
}
