package hks.utils;


import org.apache.commons.lang3.time.FastDateFormat;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.ParseException;
import java.util.*;
import java.util.function.Supplier;

public class Ops {

    public static void main(String[] args) {
    }

    public static <T> T of(T t, T def) {
        return Objects.requireNonNullElse(t, def);
    }

    public static <K, V> MapBuilder<K, V> map() {
        return new MapBuilder<>();
    }

    public static <K, V> MapBuilder<K, V> map(K k, V v) {
        MapBuilder<K, V> builder = new MapBuilder<>();
        builder.put(k, v);
        return builder;
    }

    public static class MapBuilder<K, V> {
        private final Map<K, V> map;
        public MapBuilder() {
            map = new HashMap<>();
        }
        public MapBuilder<K, V> put(K key, V value) {
            map.put(key, value);
            return this;
        }
        public Map<K, V> get() {
            return map;
        }
    }

    public static <E> ListBuilder<E> list() {
        return new ListBuilder<>();
    }

    public static <E> ListBuilder<E> list(E e) {
        ListBuilder<E> builder = new ListBuilder<>();
        builder.add(e);
        return builder;
    }

    public static class ListBuilder<E> {
        private final List<E> list;
        public ListBuilder() {
            list = new ArrayList<>();
        }
        public ListBuilder<E> add(E e) {
            list.add(e);
            return this;
        }
        public List<E> get() {
            return list;
        }
    }

    public static String exceptionToStr(Throwable e) {
        if (e == null){
            return "";
        }
        var stringWriter = new StringWriter();
        e.printStackTrace(new PrintWriter(stringWriter));
        return stringWriter.toString();
    }

    public static String extract(String str, String pre, String suffix) {
        return str.substring(str.indexOf(pre) + pre.length(), str.indexOf(suffix));
    }

    public static Object runQuietly(Supplier<Object> fun) {
        try {
            return fun.get();
        } catch (Exception ex) {
            return exceptionToStr(ex);
        }
    }

    public static Date parse(FastDateFormat f, String dateStr) {
        try {
            return f.parse(dateStr);
        } catch (ParseException e) {
            throw new RuntimeException("parse str to date error! str=" + dateStr, e);
        }
    }

    public static boolean canTradeStock(long ts) {
        var calendar = Calendar.getInstance();
        calendar.setTimeInMillis(ts);
        int weekDay = calendar.get(Calendar.DAY_OF_WEEK);
        if (weekDay == Calendar.SATURDAY || weekDay == Calendar.SUNDAY) {
            return false;
        }
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int min = calendar.get(Calendar.MINUTE);
        if ((hour >= 9 && hour <= 11) || (hour >= 13 && hour < 15)) {
            if (hour == 9) {
                return min >= 30;
            } else if (hour == 11) {
                return min < 30;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }
}
