package hks.utils;

import okhttp3.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class OkHttpOps {

    public static String doGet(String url) {
        return doGet(url, null);
    }

    public static String doGet(String url, Map<String, Object> params) {
        return doGet(url, params, null);
    }

    public static String doGet(String url, Map<String, Object> params, Map<String, String> headers) {
        var okHttpClient = new OkHttpClient();
        var builder = new Request.Builder();
        if (headers != null && !headers.isEmpty()) {
            builder = builder.headers(Headers.of(headers));
        }
        var req = builder.get().url(url + paramsToStr(params))
                .build();
        var call = okHttpClient.newCall(req);
        try {
            var res = call.execute();
            var rb = res.body();
            if (!res.isSuccessful() || rb == null) {
                throw new RuntimeException(res.toString());
            }
            return rb.string();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private static String paramsToStr(Map<String, Object> params) {
        if (params == null || params.isEmpty()) {
            return "";
        }
        List<String> lstParam = new ArrayList<>(params.size());
        for (Map.Entry<String, Object> entry : params.entrySet()) {
            lstParam.add(entry.getKey() + "=" + entry.getValue());
        }
        return "?" + String.join("&", lstParam);
    }

    public static String doPost(String url) {
        return doPost(url, null, null);
    }

    public static String doPost(String url, Map<String, Object> params) {
        return doPost(url, params, null);
    }

    public static String doPost(String url, Map<String, Object> params, Map<String, String> headers) {
        var okHttpClient = new OkHttpClient();
        var builder = new Request.Builder();
        if (headers != null && !headers.isEmpty()) {
            builder = builder.headers(Headers.of(headers));
        }
        var fbBuilder = new FormBody.Builder();
        if (params != null) {
            for (Map.Entry<String, Object> entry : params.entrySet()) {
                fbBuilder.add(entry.getKey(), entry.getValue().toString());
            }
        }
        var req = builder.post(fbBuilder.build()).url(url)
                .build();
        var call = okHttpClient.newCall(req);
        ResponseBody rb = null;
        try {
            var res = call.execute();
            rb = res.body();
            if (!res.isSuccessful() || rb == null) {
                throw new RuntimeException(res.message());
            }
            res.close();
            return rb.toString();
        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            if (rb != null) {
                rb.close();
            }
        }
    }


}
