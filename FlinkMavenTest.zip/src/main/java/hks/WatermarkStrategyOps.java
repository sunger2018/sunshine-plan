package hks;

import org.apache.flink.api.common.eventtime.WatermarkStrategy;

import java.time.Duration;

public interface WatermarkStrategyOps<T> extends WatermarkStrategy<T> {
    /**
     * 返回自定义的Watermark生成策略
     *
     * @param maxOutOfOrderness 乱序时间
     * @param <T>               数据来源泛型
     * @return 自定义的Watermark生成策略
     */
    static <T> WatermarkStrategy<T> forBoundedNewWatermark(Duration maxOutOfOrderness) {
        return (ctx) -> new BoundedNewWatermarks<>(maxOutOfOrderness);
    }
}
