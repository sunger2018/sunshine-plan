package hks;

import hks.functions.Fun3;
import org.apache.flink.api.java.tuple.Tuple5;

import java.lang.reflect.Array;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.Temporal;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import static hks.utils.Ops.*;

public class JavaTest {

    public static void main(String[] args) {
        Duration.between(LocalDateTime.now(), LocalDateTime.now());

        //LocalDateTime d = LocalDateTime.ofInstant(Instant.ofEpochMilli(1L), ZoneId.systemDefault())

        var ss = List.of(new int[]{1, 2, 3});

        String str = of("abc", "null");

        testFun((a, b, c) -> a + b + c + "abc", "1", 3, 6);

        Optional<Integer> max = Stream.of(1, 5, 7, 2, 10, 30, 99, 38).max(Comparator.comparing(Integer::intValue));

        System.out.println(max.get());
    }

    public static <A, B, C, R> void testFun(Fun3<? super A, ? super B, ? super C, ? extends R> f, A a, B b, C c) {
        System.out.println(f.apply(a, b, c));
    }

    public static void test() {
        var t = Tuple5.of(1, 2, 3, 4, 5);
        var list = List.of(1, 2, 3);
        var collect = list.stream().map(a -> a.toString() + "abc").collect(Collectors.toList());
        List<Integer> integerList = Stream.of(1, 2, 3).map(a -> 10 * a).collect(Collectors.toList());

        List<String> a = Stream.of(1, 2, 3).map(new Function<Object, String>() {
            @Override
            public String apply(Object obj) {
                return obj.toString();
            }
        }).collect(Collectors.toList());
        List<Integer> b = Stream.of(1, 2, 3).sorted(new Comparator<Object>() {
            @Override
            public int compare(Object o1, Object o2) {
                return o1.hashCode() - o2.hashCode();
            }
        }).collect(Collectors.toList());
    }

    @SuppressWarnings("unchecked")
    public static <T> T[] createArr(Class<T> clazz, int size) {
        return (T[]) Array.newInstance(clazz, size);
    }
}

class Screen{
    public static void show(){
        System.out.println("Static method from parent class");
    }
}
class ColorScreen extends Screen{
    public static void show(){
        System.err.println("Overridden static method in Child Class in Java");
    }
}
