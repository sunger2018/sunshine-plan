package hks.structure;

public class HLinkedList {

    public HNode head;

    private int size;

    public static void main(String[] args) {
        var list = new HLinkedList();
        list.newLink(1, 10, 8, 33, 21, 87, 24, 40, 9, 72, 11);
        System.out.println(list);
        list.reverse();
        System.out.println(list);
    }

    public void newLink(int ... vs) {
        HNode node = null;
        for (int v : vs) {
            node = insertAfter(node, v);
        }
    }

    public void reverse() {
        HNode p1 = null;
        HNode p2 = head;
        HNode p3;
        while (p2 != null) {
            p3 = p2.next;
            p2.next = p1;
            p1 = p2;
            p2 = p3;
            if (p2 == null) {
                head = p1;
            }
        }
    }

    public HNode insertAfter(HNode prev, int value) {
        if (prev == null) {
            head = new HNode(value);
            size++;
            return head;
        }
        var node = new HNode(value);
        prev.next = node;
        size++;
        return node;
    }

    public String toString() {
        var sb = new StringBuilder(size * 3);
        var curr = head;
        var i = 0;
        while (curr != null) {
            if (i != 0) {
                sb.append(" -> ");
            }
            sb.append(curr.value);
            curr = curr.next;
            i++;
        }

        return sb.toString();
    }

    public static class HNode {

        public int value;

        public HNode next;

        public HNode(int value) {
            this.value = value;
            this.next = null;
        }

        public HNode(int value, HNode next) {
            this.value = value;
            this.next = next;
        }
    }
}
