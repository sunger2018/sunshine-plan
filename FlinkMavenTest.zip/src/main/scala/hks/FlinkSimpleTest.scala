package hks

import org.apache.flink.api.common.typeinfo.TypeInformation
import org.apache.flink.api.scala.typeutils.Types
import org.apache.flink.streaming.api.TimeCharacteristic
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.types.{Row, RowKind}
import org.apache.flink.streaming.api.scala._
import org.apache.flink.table.api.StatementSet
import org.apache.flink.table.api.bridge.scala._

object FlinkSimpleTest {

  def main(args: Array[String]): Unit = {
    val env = StreamExecutionEnvironment.createLocalEnvironment(2)
    env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime)
    val dataStream =
      env.fromElements(
        Row.ofKind(RowKind.INSERT, "Alice", Int.box(10)),
        Row.ofKind(RowKind.INSERT, "Bob", Int.box(5)),
        Row.ofKind(RowKind.UPDATE_BEFORE, "Alice", Int.box(10)),
        Row.ofKind(RowKind.UPDATE_AFTER, "Alice", Int.box(100)))(Types.ROW(Types.STRING, Types.INT))

    val tableEnv = StreamTableEnvironment.create(env)
    val table = dataStream.toChangelogTable(tableEnv)
    val ss = tableEnv.createStatementSet()
    ss.add(table.insertInto(""))
    ss.addInsertSql("")

    tableEnv.sqlQuery("CREATE TABLE MyTable")

    tableEnv.createTemporaryView("InputTable", table);
    tableEnv
      .executeSql("SELECT f0 AS name, SUM(f1) AS score FROM InputTable GROUP BY f0")
      .print();

  }
}
