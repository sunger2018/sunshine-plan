package hks

import hks.model.Order
import hks.util.SteamEnvOps._
import org.apache.flink.api.common.eventtime.{SerializableTimestampAssigner, WatermarkStrategy}
import org.apache.flink.api.common.functions.AggregateFunction
import org.apache.flink.api.java.io.TextInputFormat
import org.apache.flink.api.java.utils.ParameterTool
import org.apache.flink.shaded.jackson2.com.fasterxml.jackson.databind.ObjectMapper
import org.apache.flink.streaming.api.functions.source.FileProcessingMode
import org.apache.flink.streaming.api.scala._
import org.apache.flink.streaming.api.scala.function.ProcessWindowFunction
import org.apache.flink.streaming.api.windowing.assigners.TumblingEventTimeWindows
import org.apache.flink.streaming.api.windowing.time.Time
import org.apache.flink.streaming.api.windowing.windows.TimeWindow
import org.apache.flink.util.Collector

import java.sql.Timestamp
import java.text.SimpleDateFormat
import java.time.Duration

object FlinkFileTest {
  def main(args: Array[String]): Unit = {
    val ps = ParameterTool.fromArgs(args)
    val pf = ParameterTool.fromPropertiesFile(ps.get("configFile"))
    val checkpointUrl = pf.get("checkpointUrl") // --outfile path
    println(checkpointUrl)



    val env = StreamExecutionEnvironment.getExecutionEnvironment
    // env.setMaxParallelism(128)
    env.configCheckpoint(checkpointUrl, 60)

    val sourcePath = "/Users/huangkaoshan/Documents/work/out.txt"
    val source = env.readFile(new TextInputFormat(null), sourcePath, FileProcessingMode.PROCESS_CONTINUOUSLY, 1000L)

    val mapper = new ObjectMapper()
    val stream = source.map(s => mapper.readValue(s, classOf[Order]))
      .assignTimestampsAndWatermarks(WatermarkStrategyOps
        .forBoundedNewWatermark(Duration.ofSeconds(10))
        .withTimestampAssigner(new SerializableTimestampAssigner[Order] {
          def extractTimestamp(t: Order, l: Long): Long = t.ts
        })).name("source-map").uid("source-map")

    type int3 = (String, Int, Int, Int)
    type int4 = (String, Int, Int, Int, Double)
    val sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    val sdf2 = new SimpleDateFormat("HH:mm:ss")

    val lateOrderTag = new OutputTag[Order]("lateOrder")
    val resultStream = stream.keyBy(_.userId)
      .window(TumblingEventTimeWindows.of(Time.days(1), Time.hours(-8)))
      //.window(TumblingEventTimeWindows.of(Time.seconds(10)))
      .trigger(EventTimeIntervalTrigger.of[Order](Time.seconds(10)))
      .allowedLateness(Time.seconds(10))
      .sideOutputLateData(lateOrderTag)
      .aggregate(new AggregateFunction[Order, int3, int4] {
        def createAccumulator(): int3 = ("", 0, 0, 0)

        def add(in: Order, acc: int3): int3 = (in.userId, 1 + acc._2, in.amount + acc._3, Math.max(in.amount, acc._4))

        def getResult(acc: int3): int4 = (acc._1, acc._2, acc._3, acc._4, round(acc._3 * 1.0 / acc._2, 2))

        def merge(a: int3, b: int3): int3 = (a._1, a._2 + b._2, a._3 + b._3, Math.max(a._4, b._4))
      }, new ProcessWindowFunction[int4, String, String, TimeWindow] {
        def process(key: String, ctx: Context, itr: Iterable[int4], out: Collector[String]): Unit = {
          val windowInfo = sdf.format(new Timestamp(ctx.window.getStart))
          val ts = sdf2.format(new Timestamp(System.currentTimeMillis()))
          val a = itr.head
          out.collect(OrderSum(windowInfo, key, a._2, a._3, a._4, a._5, ts).toString)
        }
      }).name("keyed-win").uid("keyed-win").setParallelism(3).rebalance
    resultStream.addSink(new HttpSink[String]).name("http-sink").uid("http-sink").setParallelism(2)

    stream.getSideOutput(lateOrderTag).print()


    env.execute("FlinkFileTest")
  }

  case class OrderSum(win: String, userId: String, count: Int, sum: Int, max: Int, avg: Double, ts: String) {
    override def toString: String = {
      s"""{win=${win}, userId=${userId}, count=${count}, sum=${sum}, max=${max}, avg=${avg}, ts=${ts}""".stripMargin
    }
  }

}
