package hks

import org.apache.flink.api.common.serialization.SimpleStringEncoder
import org.apache.flink.api.java.utils.ParameterTool
import org.apache.flink.configuration.{ConfigOption, ConfigOptions, MemorySize}
import org.apache.flink.connector.file.sink.FileSink
import org.apache.flink.core.fs.Path
import org.apache.flink.streaming.api.functions.sink.filesystem.rollingpolicies.DefaultRollingPolicy
import org.apache.flink.streaming.api.scala._
import org.apache.flink.streaming.api.scala.function._
import org.apache.flink.streaming.api.windowing.assigners.TumblingProcessingTimeWindows
import org.apache.flink.streaming.api.windowing.time.Time
import org.apache.flink.streaming.api.windowing.windows.TimeWindow
import org.apache.flink.util.Collector

import java.time.Duration

object FlinkTest {
  def main(args: Array[String]): Unit = {
    val ps = ParameterTool.fromArgs(args)
    val pf = ParameterTool.fromPropertiesFile(ps.get("configFile"))
    val outfile = pf.get("outfile") // --outfile path
    println(outfile)

    val env = StreamExecutionEnvironment.getExecutionEnvironment
    // env.getConfiguration.get(ConfigOptions.key("rest.address").stringType().defaultValue(""))
    configCheckpoint(env, "", 60)

    val stream = env.socketTextStream("localhost", 9000, '\n')
    val sumStream = stream.flatMap(_.split(" ")).map((_, 1))
      .keyBy(_._1).window(TumblingProcessingTimeWindows.of(Time.seconds(10)))
      .process(new ProcessWindowFunction[(String, Int), (String, Int), String, TimeWindow] {
        def process(key: String, ctx: Context, itr: Iterable[(String, Int)], out: Collector[(String, Int)]): Unit = {
          val max = itr.toSeq.maxBy(_._2)
          out.collect(max)
        }
      })

    sumStream.sinkTo(
      getFileSink[(String, Int)](outfile)
    )

    env.execute("WordCount")
  }


}
