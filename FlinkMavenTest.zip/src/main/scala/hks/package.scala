import org.apache.flink.api.common.restartstrategy.RestartStrategies
import org.apache.flink.api.common.serialization.SimpleStringEncoder
import org.apache.flink.api.common.time.Time
import org.apache.flink.connector.file.sink.FileSink
import org.apache.flink.contrib.streaming.state.EmbeddedRocksDBStateBackend
import org.apache.flink.core.fs.Path
import org.apache.flink.streaming.api.CheckpointingMode
import org.apache.flink.streaming.api.functions.sink.filesystem.rollingpolicies.DefaultRollingPolicy
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment

import java.math.RoundingMode
import java.time.Duration
import java.util.concurrent.TimeUnit

package object hks {
  def configCheckpoint(env: StreamExecutionEnvironment, checkpointPath:String, interval: Int): Unit = {
    val conf = env.getCheckpointConfig
    env.setStateBackend(new EmbeddedRocksDBStateBackend(true))
    conf.setCheckpointStorage(s"file://${checkpointPath}")
    conf.setCheckpointingMode(CheckpointingMode.AT_LEAST_ONCE)
    conf.setCheckpointInterval(interval * 1000)
    conf.setMaxConcurrentCheckpoints(1)
    conf.setTolerableCheckpointFailureNumber(5)
    env.setRestartStrategy(RestartStrategies.fixedDelayRestart(3, Time.of(10,TimeUnit.SECONDS)))
  }

  def getFileSink[T](outfile: String): FileSink[T] = {
    FileSink.forRowFormat(new Path(outfile),
      new SimpleStringEncoder[T]("UTF-8"))
      .withRollingPolicy(
        DefaultRollingPolicy.builder()
          .withRolloverInterval(Duration.ofDays(365))
          //.withInactivityInterval(Duration.ofHours(24))
          //.withMaxPartSize(MemorySize.ofMebiBytes(1024 * 1024 * 128))
          .build()
      ).build()
  }

  def round(d: Double, scale: Int): Double = {
    new java.math.BigDecimal(d).setScale(scale, RoundingMode.HALF_UP).doubleValue()
  }
}
