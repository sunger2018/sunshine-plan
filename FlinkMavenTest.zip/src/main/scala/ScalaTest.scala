object ScalaTest {
  def main(args: Array[String]): Unit = {
    val ss = (1, 2, 3)
    println("abc")
  }
}
